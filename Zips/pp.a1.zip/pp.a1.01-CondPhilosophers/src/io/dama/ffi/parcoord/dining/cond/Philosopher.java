package io.dama.ffi.parcoord.dining.cond;

import java.util.concurrent.locks.Lock;

public class Philosopher extends Thread implements IPhilosopher {

    @Override
    public void setLeft(final IPhilosopher left) {
        // TODO Auto-generated method stub
        // Cast auf Philosopher erforderlich
    }

    @Override
    public void setRight(final IPhilosopher right) {
        // TODO Auto-generated method stub
        // Cast auf Philosopher erforderlich
    }

    @Override
    public void setSeat(final int seat) {
        // TODO Auto-generated method stub

    }

    @Override
    public void setTable(final Lock table) {
        // TODO Auto-generated method stub

    }

    @Override
    public void stopPhilosopher() {
        // TODO Auto-generated method stub

    }
}
