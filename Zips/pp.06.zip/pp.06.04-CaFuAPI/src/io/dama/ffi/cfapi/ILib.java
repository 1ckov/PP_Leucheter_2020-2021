package io.dama.ffi.cfapi;

public interface ILib {
    public Integer calcSync() throws Exception;
}
