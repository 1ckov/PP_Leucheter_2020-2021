# Thread-Sicherheit von Collections #

## SynchronizedCollection-Wrapper ##

## Lösungsskizze ##

* ``implements List<T>`` hinzufügen und die zu überschreibenden Methodenrümpfe generieren lassen.
* Jede generierte Methode als ``synchronized`` kennzeichnen.
* die Implementierung jeder zu überschreibenden Methode erfolgt durch die Anwendung derselben (unsynchronisierten) Methode an der dekorierten ``Collection``-Instanz 

## weitere Informationen ##
Eine optimierte Variante finden Sie bei *Apache Common Collections*:

[https://github.com/apache/commons-collections/blob/master/src/main/java/org/apache/commons/collections4/collection/SynchronizedCollection.java](https://github.com/apache/commons-collections/blob/master/src/main/java/org/apache/commons/collections4/collection/SynchronizedCollection.java) 
