package io.dama.ffi.coll;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class SynchWrapperRW<T> implements List<T> {
    private static final int SIZE = 10000;
    private final List<T> decorated;
    private final ReadWriteLock lock;
    private final Lock rLock;
    private final Lock wLock;

    // s. public static <K, V> boolean compare in:
    // https://docs.oracle.com/javase/tutorial/java/generics/methods.html
    // "For static generic methods, the type parameter section must appear
    // before the method's return type."
    static <T> List<T> synchronizedList(final List<T> list) {
        return new SynchWrapperRW<>(list);
    }

    private SynchWrapperRW(final List<T> list) {
        this.decorated = list;
        this.lock = new ReentrantReadWriteLock();
        this.rLock = this.lock.readLock();
        this.wLock = this.lock.writeLock();
    }

    @Override
    public int size() {
        this.rLock.lock();
        try {
            return this.decorated.size();
        } finally {
            this.rLock.unlock();
        }
    }

    @Override
    public boolean isEmpty() {
        this.rLock.lock();
        try {
            return this.decorated.isEmpty();
        } finally {
            this.rLock.unlock();
        }
    }

    @Override
    public boolean contains(final Object o) {
        this.rLock.lock();
        try {
            return this.decorated.contains(o);
        } finally {
            this.rLock.unlock();
        }
    }

    @Override
    public Iterator<T> iterator() {
        this.rLock.lock();
        try {
            return this.decorated.iterator();
        } finally {
            this.rLock.unlock();
        }
    }

    @Override
    public Object[] toArray() {
        this.rLock.lock();
        try {
            return this.decorated.toArray();
        } finally {
            this.rLock.unlock();
        }
    }

    @Override
    public <T> T[] toArray(final T[] a) {
        this.rLock.lock();
        try {
            return this.decorated.toArray(a);
        } finally {
            this.rLock.unlock();
        }
    }

    @Override
    public boolean add(final T e) {
        this.wLock.lock();
        try {
            return this.decorated.add(e);
        } finally {
            this.wLock.unlock();
        }
    }

    @Override
    public boolean remove(final Object o) {
        this.wLock.lock();
        try {
            return this.decorated.remove(o);
        } finally {
            this.wLock.unlock();
        }
    }

    @Override
    public boolean containsAll(final Collection<?> c) {
        this.rLock.lock();
        try {
            return this.decorated.containsAll(c);
        } finally {
            this.rLock.unlock();
        }
    }

    @Override
    public boolean addAll(final Collection<? extends T> c) {
        this.wLock.lock();
        try {
            return this.decorated.addAll(c);
        } finally {
            this.wLock.unlock();
        }
    }

    @Override
    public boolean addAll(final int index, final Collection<? extends T> c) {
        this.wLock.lock();
        try {
            return this.decorated.addAll(index, c);
        } finally {
            this.wLock.unlock();
        }
    }

    @Override
    public boolean removeAll(final Collection<?> c) {
        this.wLock.lock();
        try {
            return this.decorated.removeAll(c);
        } finally {
            this.wLock.unlock();
        }
    }

    @Override
    public boolean retainAll(final Collection<?> c) {
        this.wLock.lock();
        try {
            return this.decorated.retainAll(c);
        } finally {
            this.wLock.unlock();
        }
    }

    @Override
    public void clear() {
        this.wLock.lock();
        try {
            this.decorated.clear();
        } finally {
            this.wLock.unlock();
        }
    }

    @Override
    public T get(final int index) {
        this.rLock.lock();
        try {
            return this.decorated.get(index);
        } finally {
            this.rLock.unlock();
        }
    }

    @Override
    public T set(final int index, final T element) {
        this.wLock.lock();
        try {
            return this.decorated.set(index, element);
        } finally {
            this.wLock.unlock();
        }
    }

    @Override
    public void add(final int index, final T element) {
        this.wLock.lock();
        try {
            this.decorated.add(index, element);
        } finally {
            this.wLock.unlock();
        }
    }

    @Override
    public T remove(final int index) {
        this.wLock.lock();
        try {
            return this.decorated.remove(index);
        } finally {
            this.wLock.unlock();
        }
    }

    @Override
    public int indexOf(final Object o) {
        this.rLock.lock();
        try {
            return this.decorated.indexOf(o);
        } finally {
            this.rLock.unlock();
        }
    }

    @Override
    public int lastIndexOf(final Object o) {
        this.rLock.lock();
        try {
            return this.decorated.lastIndexOf(o);
        } finally {
            this.rLock.unlock();
        }
    }

    @Override
    public ListIterator<T> listIterator() {
        this.rLock.lock();
        try {
            return this.decorated.listIterator();
        } finally {
            this.rLock.unlock();
        }
    }

    @Override
    public ListIterator<T> listIterator(final int index) {
        this.rLock.lock();
        try {
            return this.decorated.listIterator(index);
        } finally {
            this.rLock.unlock();
        }
    }

    @Override
    public List<T> subList(final int fromIndex, final int toIndex) {
        this.rLock.lock();
        try {
            return this.decorated.subList(fromIndex, toIndex);
        } finally {
            this.rLock.unlock();
        }
    }

    public static void main(final String... args) throws InterruptedException {
        var l = new SynchWrapperRW<>(new ArrayList<Integer>());
        var t1 = new Thread(() -> {
            for (var i = 0; i < SynchWrapperRW.SIZE; i++) {
                l.add(Integer.valueOf(i));
            }
        });
        var t2 = new Thread(() -> {
            for (var i = 0; i < SynchWrapperRW.SIZE; i++) {
                l.add(Integer.valueOf(i));
            }
        });
        t1.start();
        t2.start();
        t1.join();
        t2.join();
        System.out.println((l.size() == (SynchWrapperRW.SIZE * 2)) ? "OK" : "Fehler");
    }
}
