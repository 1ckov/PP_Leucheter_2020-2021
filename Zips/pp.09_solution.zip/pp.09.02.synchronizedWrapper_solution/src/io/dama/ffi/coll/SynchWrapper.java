package io.dama.ffi.coll;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class SynchWrapper<T> implements List<T> {
    private static final int SIZE = 10000;
    private final List<T> decorated;

    // s. public static <K, V> boolean compare in:
    // https://docs.oracle.com/javase/tutorial/java/generics/methods.html
    // "For static generic methods, the type parameter section must appear
    // before the method's return type."
    static <T> List<T> synchronizedList(final List<T> list) {
        return new SynchWrapper<>(list);
    }

    private SynchWrapper(final List<T> list) {
        this.decorated = list;
    }

    @Override
    public synchronized int size() {
        return this.decorated.size();
    }

    @Override
    public synchronized boolean isEmpty() {
        return this.decorated.isEmpty();
    }

    @Override
    public synchronized boolean contains(final Object o) {
        return this.decorated.contains(o);
    }

    @Override
    public synchronized Iterator<T> iterator() {
        return this.decorated.iterator();
    }

    @Override
    public synchronized Object[] toArray() {
        return this.decorated.toArray();
    }

    @Override
    public synchronized <T> T[] toArray(final T[] a) {
        return this.decorated.toArray(a);
    }

    @Override
    public synchronized boolean add(final T e) {
        return this.decorated.add(e);
    }

    @Override
    public synchronized boolean remove(final Object o) {
        return this.decorated.remove(o);
    }

    @Override
    public synchronized boolean containsAll(final Collection<?> c) {
        return this.decorated.containsAll(c);
    }

    @Override
    public synchronized boolean addAll(final Collection<? extends T> c) {
        return this.decorated.addAll(c);
    }

    @Override
    public synchronized boolean addAll(final int index, final Collection<? extends T> c) {
        return this.decorated.addAll(index, c);
    }

    @Override
    public synchronized boolean removeAll(final Collection<?> c) {
        return this.decorated.removeAll(c);
    }

    @Override
    public synchronized boolean retainAll(final Collection<?> c) {
        return this.decorated.retainAll(c);
    }

    @Override
    public synchronized void clear() {
        this.decorated.clear();
    }

    @Override
    public synchronized T get(final int index) {
        return this.decorated.get(index);
    }

    @Override
    public synchronized T set(final int index, final T element) {
        return this.decorated.set(index, element);
    }

    @Override
    public synchronized void add(final int index, final T element) {
        this.decorated.add(index, element);
    }

    @Override
    public synchronized T remove(final int index) {
        return this.decorated.remove(index);
    }

    @Override
    public synchronized int indexOf(final Object o) {
        return this.decorated.indexOf(o);
    }

    @Override
    public synchronized int lastIndexOf(final Object o) {
        return this.decorated.lastIndexOf(o);
    }

    @Override
    public synchronized ListIterator<T> listIterator() {
        return this.decorated.listIterator();
    }

    @Override
    public synchronized ListIterator<T> listIterator(final int index) {
        return this.decorated.listIterator(index);
    }

    @Override
    public synchronized List<T> subList(final int fromIndex, final int toIndex) {
        return this.decorated.subList(fromIndex, toIndex);
    }

    public static void main(final String... args) throws InterruptedException {
        var l = new SynchWrapper<>(new ArrayList<Integer>());
        var t1 = new Thread(() -> {
            for (var i = 0; i < SynchWrapper.SIZE; i++) {
                l.add(Integer.valueOf(i));
            }
        });
        var t2 = new Thread(() -> {
            for (var i = 0; i < SynchWrapper.SIZE; i++) {
                l.add(Integer.valueOf(i));
            }
        });
        t1.start();
        t2.start();
        t1.join();
        t2.join();
        System.out.println((l.size() == (SynchWrapper.SIZE * 2)) ? "OK" : "Fehler");
    }
}
