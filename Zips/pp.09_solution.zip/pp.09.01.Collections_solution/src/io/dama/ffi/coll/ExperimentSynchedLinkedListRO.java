package io.dama.ffi.coll;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

class ExperimentSynchedLinkedListRO {
    Integer countA;
    Integer countB;
    List<Integer> list;
    List<Integer> listSynch;
    List<Integer> listRO;

    void work(final int size) throws InterruptedException {
        this.countA = 0;
        this.countB = 0;
        this.list = new LinkedList<>();
        this.listSynch = Collections.synchronizedList(this.list);
        this.listRO = Collections.unmodifiableList(this.list);

        var t1 = new Thread(() -> {
            for (var i = 0; i < size; i++) {
                this.listSynch.add(1);
            }
        });
        var t2 = new Thread(() -> {
            for (var i = 0; i < size; i++) {
                this.listSynch.add(1);
            }
        });
        var t3 = new Thread(() -> {
            for (var i = 0; i < (size * 2); i++) {
                this.countA += this.listRO.get(i);
            }
        });
        var t4 = new Thread(() -> {
            for (var i = (size * 2) - 1; i >= 0; i--) {
                this.countB += this.listRO.get(i);
            }
        });
        var now = System.currentTimeMillis();
        t1.start();
        t2.start();
        t1.join();
        t2.join();
        t3.start();
        t4.start();
        t3.join();
        t4.join();
        System.out.printf("Lauf %s, i=%d, Zeitdauer: %dms (%s)\n",
                (this.countA.equals(this.countB)) ? "ok" : "fehlerhaft", size, System.currentTimeMillis() - now,
                "SynchedLinkedListRO");
    }

}
