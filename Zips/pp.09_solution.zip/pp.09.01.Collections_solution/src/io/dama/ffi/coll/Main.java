package io.dama.ffi.coll;

public class Main {

    public static void main(final String... args) {
        for (var i = 100; i <= 100000; i *= 10) {
            try {
                (new ExperimentVector()).work(i);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            try {
                (new ExperimentArrayList()).work(i);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            try {
                (new ExperimentLinkedList()).work(i);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            try {
                (new ExperimentSynchedArrayList()).work(i);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            try {
                (new ExperimentSynchedLinkedList()).work(i);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            try {
                (new ExperimentSynchedLinkedListRO()).work(i);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
