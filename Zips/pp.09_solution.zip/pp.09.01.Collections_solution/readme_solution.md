# Thread-Sicherheit von Collections #

## Vergleich von ``Vector``, ``LinkedList``, ``ArrayList`` und den synchronisierten Varianten ##

## Lösungsskizze ##
* Erstellen Sie ein Programm, mit dem Sie die Performanz unterschiedlicher Listeninplementierungen messen können. 
  * unabhängige Variablen: Größe der Aufgabe (z.B. Länge der Liste), Listenimplementierung 

    Die eine unabhängige Variable *"Listenimplementierung"* wird darüber realisiert, dass die ``work``-Methode wie in ``ExperimentVector`` in entsprechenden Klassen dupliziert wird. In jeder dieser Klassen wird eine andere Implementierung von ``List`` verwendet:
    
    - ``ExperimentVector``: ``new Vector<>()``
    - ``ExperimentArrayList``: ``new ArrayList<>()``
    - ``ExperimentLinkedList``: ``new LinkedList<>()``
    - ``ExperimentSynchedArrayList``: ``Collections.synchronizedList(new ArrayList<>())``
    - ``ExperimentSynchedLinkedList``: ``Collections.synchronizedList(new LinkedList<>())``
    - ``ExperimentSynchedLinkedListRO``: synchronizedList für Mutator, unmodifiable List für ``get``
    
    In der ``Main``-Klasse werden die ``work``-Methoden der unterschiedlichen Implementierungen aufgerufen. Aus der umgebenen Schleife wird ein Parameter mit der unabhängigen Variable *"Aufgabengröße"* (``i``) in Zehnerpotenzen hochgezählt.
    
  
  * abhängige Variable: Laufzeit
  
  Die Zeit wird in der ``work``-Methode gemessen.
  
  * Berücksichtigen Sie Threadsicherheit und verwenden Sie mindestens zwei Threads, die nebenläufig auf die Liste zugreifen 
* Führen Sie Messungen der Laufzeit durch.
* Visualisieren Sie die Ergebnisse und analysiseren Sie das Ergebnis.

 Die unabhängigen Variablen als Spate und Zeile in einer Tabelle verwenden. Die gemessene Ausprägung der abhängigen Variablen in den jeweiligen Zellen eintragen. Dann eine Abbildung wie in Moodle gezeigt erzeugen.

