package io.dama.ffi.forkjoin;

import java.util.ArrayList;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;

@SuppressWarnings("serial")
public class FilterTask extends RecursiveAction {

    private static final int ARRAY_LEN = 16;
    private static final int SLICE_LEN = 4;
    private static final int MAX = 10;
    private static int instanceCounter = 0;

    private final ArrayList<Integer> array;
    private final int start;
    private final int end;

    FilterTask(final ArrayList<Integer> array, final int start, final int end) {
        this.array = array;
        this.start = start;
        this.end = end;
        instanceCounter++;
    }

    @Override
    protected void compute() {
        if ((this.end - this.start) <= SLICE_LEN) {
            for (var i = this.start; i < this.end; i++) {
                if (this.array.get(i) > MAX) {
                    this.array.set(i, MAX);
                }
            }
        } else {
            var mid = this.start + ((this.end - this.start) / 2);
            var left = new FilterTask(this.array, this.start, mid);
            var right = new FilterTask(this.array, mid, this.end);
            left.fork();
            right.fork();
            left.join();
            right.join();
        }
    }

    public static void main(final String... args) {
        var array = new ArrayList<Integer>();
        for (var i = 0; i < ARRAY_LEN; i++) {
            array.add(i + 1);
        }
        var task = new FilterTask(array, 0, array.size());
        ForkJoinPool.commonPool().invoke(task);
        for (var number : array) {
            System.out.print(number + " ");
        }
        System.out.println("\nAnzahl der verwendeten Instanzen von FilterTask: " + instanceCounter);
    }
}
