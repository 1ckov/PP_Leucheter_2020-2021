package io.dama.ffi.forkjoin;

import java.util.ArrayList;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;
import java.util.function.BiFunction;

@SuppressWarnings("serial")
public class ReduceTaskGeneric<T> extends RecursiveTask<T> {
    // Der Typ der Elemente im Container ist T (statt Integer).
    // Dieser Typ wird Parameter von ReduceTaskGeneric.

    private static int ARRAY_LEN = 16;
    private static int SLICE_LEN = 4;

    private final ArrayList<T> array;
    private final int start;
    private final int end;

    // generische Lösung: statt + wird die BiFunction aggregateFunc benutzt
    // aggregateFunc ist ein Objekt, das die Funktion
    // T apply(T x, T y)
    // beinhaltet. Sie wird später statt + aufgerufen
    private final BiFunction<T, T, T> aggregFun;
    // als Start wird ein Ersatz für 0 benötigt. Dieser initiale Wert muss vom Typ T
    // sein
    private final T initAcc;

    ReduceTaskGeneric(final BiFunction<T, T, T> aggregFun, final T initAcc, final ArrayList<T> array, final int start,
            final int end) {
        this.array = array;
        this.start = start;
        this.end = end;
        // generische Lösung: aggregFun und initAcc müssen über den Konstruktor
        // übergeben werden
        this.aggregFun = aggregFun;
        this.initAcc = initAcc;
    }

    @Override
    protected T compute() { // satt Integer T als Rückgabetyp
        var accumulator = this.initAcc; // statt 0 initAcc
        if ((this.end - this.start) <= SLICE_LEN) {
            for (var i = this.start; i < this.end; i++) {
                // statt + aggregFun.apply
                accumulator = this.aggregFun.apply(accumulator, this.array.get(i));
            }
        } else {
            var mid = this.start + ((this.end - this.start) / 2);
            var left = new ReduceTaskGeneric<>(this.aggregFun, this.initAcc, this.array, this.start, mid);
            var right = new ReduceTaskGeneric<>(this.aggregFun, this.initAcc, this.array, mid, this.end);
            left.fork();
            right.fork();

            // statt + aggregFun.apply
            accumulator = this.aggregFun.apply(left.join(), right.join());
        }
        return accumulator;
    }

    public static void main(final String... args) {
        var array = new ArrayList<Integer>();
        for (var i = 0; i < ARRAY_LEN; i++) {
            array.add(i + 1);
        }
        // Hier wird die aggregFun als Lambda-Ausdruck übergeben: (a, b) -> a + b
        // Der Typ-Parameter von ReduceTaskGeneric wird dementsprechend auf Integer
        // festgelegt.
        // Der initiale Wert des +-Akkumulators ist 0
        var task = new ReduceTaskGeneric<>(//
                ((a, b) -> a + b), // Hier wird die aggregFun als Lambda-Ausdruck übergeben: +
                0, // Der initiale Wert des +-Akkumulators ist 0.
                array, 0, array.size());
        ForkJoinPool.commonPool().invoke(task);
        // seit Java 8 alternativ: task.invoke();
        var sum = task.join();
        System.out.println("Summe: " + sum);
    }
}
