package io.dama.ffi.forkjoin;

import java.util.ArrayList;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

@SuppressWarnings("serial")
public class ReduceTask extends RecursiveTask<Integer> {

    private static int ARRAY_LEN = 16;
    private static int SLICE_LEN = 4;

    private final ArrayList<Integer> array;
    private final int start;
    private final int end;

    ReduceTask(final ArrayList<Integer> array, final int start, final int end) {
        this.array = array;
        this.start = start;
        this.end = end;
    }

    @Override
    protected Integer compute() {
        var sum = 0;
        if ((this.end - this.start) <= SLICE_LEN) {
            for (var i = this.start; i < this.end; i++) {
                sum += this.array.get(i);
            }
        } else {
            var mid = this.start + ((this.end - this.start) / 2);
            var left = new ReduceTask(this.array, this.start, mid);
            var right = new ReduceTask(this.array, mid, this.end);
            left.fork();
            right.fork();
            sum = left.join() + right.join();
        }
        return sum;
    }

    public static void main(final String... args) {
        var array = new ArrayList<Integer>();
        for (var i = 0; i < ARRAY_LEN; i++) {
            array.add(i + 1);
        }
        var task = new ReduceTask(array, 0, array.size());
        var sum = ForkJoinPool.commonPool().submit(task).join();
        System.out.println("Summe: " + sum);
    }
}
