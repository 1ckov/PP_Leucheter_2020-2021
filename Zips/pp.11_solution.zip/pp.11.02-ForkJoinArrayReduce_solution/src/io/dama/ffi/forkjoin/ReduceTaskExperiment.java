package io.dama.ffi.forkjoin;

import java.util.ArrayList;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

@SuppressWarnings("serial")
public class ReduceTaskExperiment extends RecursiveTask<Integer> {

    private static int ARRAY_LEN = 0;
    private static int SLICE_LEN = 0;

    private final ArrayList<Integer> array;
    private final int start;
    private final int end;

    ReduceTaskExperiment(final ArrayList<Integer> array, final int start, final int end) {
        this.array = array;
        this.start = start;
        this.end = end;
    }

    @Override
    protected Integer compute() {
        var sum = 0;
        if ((this.end - this.start) <= SLICE_LEN) {
            for (var i = this.start; i < this.end; i++) {
                sum += this.array.get(i);
            }
        } else {
            var mid = this.start + ((this.end - this.start) / 2);
            var left = new ReduceTaskExperiment(this.array, this.start, mid);
            var right = new ReduceTaskExperiment(this.array, mid, this.end);
            left.fork();
            right.fork();
            sum = left.join() + right.join();
        }
        return sum;
    }

    public static void main(final String... args) {
        for (ARRAY_LEN = 100; ARRAY_LEN < 10000000; ARRAY_LEN = ARRAY_LEN * 10) {
            for (SLICE_LEN = 4; SLICE_LEN < 128; SLICE_LEN = SLICE_LEN * 2) {
                var array = new ArrayList<Integer>();
                for (var i = 0; i < ARRAY_LEN; i++) {
                    array.add(i + 1);
                }
                var now = System.currentTimeMillis();
                var task = new ReduceTaskExperiment(array, 0, array.size());
                var sum = ForkJoinPool.commonPool().submit(task).join();
                System.out.printf("ARRAY_LEN: %d, SLICE_LEN: %d, Summe: %d, Zeit: %d \n", ARRAY_LEN, SLICE_LEN, sum,
                        System.currentTimeMillis() - now);
            }
        }
    }

}
