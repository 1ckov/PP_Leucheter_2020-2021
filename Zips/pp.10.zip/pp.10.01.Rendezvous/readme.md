# Exchanger und Blocking Queues  #

## Muster Rendezvous-Punkt / Go-Lang CSP in Java ##


In den Kommentaren der (ansonsten leeren) Klasse ``Addierer`` ist ein Go-Programm, das die beiden Zahlen ``1`` und ``2`` unter Zuhilfenahme von Go-Routinen (das sind nebenläufige Programmteile in der Programmiersprache Go, die "leichtgewichtiger" als Java-Threads sind) berechnet. 

Das Go-Programm besteht aus drei Funktionen. Dabei ist die Funktion ``main`` der Einstiegspunkt in die Abarbeitung (vergleichbar zur ``main``-Method ein Java). In der ``main``-Funktion werden drei Kanäle ohne Kapazitätsbeschränkung erzeugt. Die Kanäle ``c`` und ``r`` sind auf den Typ ``int`` festegelegt und der Kanal ``done`` kann nur Werte vom Typ ``bool`` beinhalten. Das Symbol ``:=`` ist eine Zuweisung des Wertes der rechten Seite an die Variable auf der linken Seite mit gleichzeitiger Deklaration der Variable auf den Typ des Wertes auf der rechten Seite.

Nachdem die Kanäle erzeugt wurden, werden die beiden Funktionen ``tasker`` und ``add`` nebenläufig als Go-Routinen gestartet (wegen des Schlüsselwortes ``go``). Der Aufruf von ``go ...`` ist asynchron, d.h. er blockiert nicht, bis der Wert der Funktion berechnet wurde. Im Gegensatz zu Futures oder Promises kann man in Go nicht direkt oder indirekt auf das Resultat einer Go-Routine zugreifen. Stattdessen muss das Ergebnis von der nebenläufig ausgeführten Funktion in einen Kanal geschrieben werden.

``tasker`` schreibt die Werte 1 und 2 in den Kanal ``c``. Liest dann einen Wert aus dem Kanal ``r`` und schreibt dann den Wert ``true`` in den Kanal ``d``. Innerhalb der Funktion sind die Namen ``r`` und ``d`` die Parameter, mit denen die Funktion ``tasker``  aufgerufen wurde. In der ``main``-Funktion wird ``tasker``mit ``c``, ``r`` und ``done`` aufgerufen. Diese drei Kanäle wird ``tasker`` also benutzen.

``add`` liest zwei Werte aus dem Kanal ``c``, addiert sie und schreibt das Ergebnis in den Kanal ``r``.

## Aufgabe ##

* Entwickeln Sie eine strukturell vergleichbare Variante dieses Programms in Java unter Zuhilfenahme von Threads zwei Threads (zusätzlich zum Main-Thread). Verwenden Sie ``LinkedBlockingQueue``, um die Go-Kanäle nachzubilden.

