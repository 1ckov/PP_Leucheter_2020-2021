import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

public class Main {
    interface Type {
    }

    interface ValType {
    }

    interface KeyType {
    }

    public static void main(final String... args) {
        var list = Collections.synchronizedList(new ArrayList<Type>());

        var myCollection = new ArrayList<Type>();
        var c = Collections.synchronizedCollection(myCollection);
        synchronized (c) {
            for (var e : c) {
                Main.foo(e);
            }
        }

        var m = Collections.synchronizedMap(new HashMap<KeyType, ValType>());
        var s = m.keySet();
        synchronized (m) {
            for (var k : s) {
                Main.foo(k);
            }
        }
    }

    private static void foo(final Object e) {

    }
}
