import java.util.ArrayList;

public class ForeachInIterator<T> {

    void iterate1() {
        var l = new ArrayList<T>();
        for (var e : l) {
            System.out.println(e);
        }
    }

    void iterate2() {
        var l = new ArrayList<T>();
        var it = l.iterator();
        while (it.hasNext()) {
            var e = it.next();
            System.out.println(e);
        }
    }
}
