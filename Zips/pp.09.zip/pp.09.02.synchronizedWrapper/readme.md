# Thread-Sicherheit von Collections #

## SynchronizedCollection-Wrapper ##

## Aufgaben ##

* Implementieren Sie einen Zugriffe synchronisierenden Wrapper für Listen analog zu dem was ``synchronizedList`` zurückliefert: 

	static List<T> synchronizedList(List<T> list) 

