package io.dama.ffi.reentrant.regular;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Worker implements Runnable {
    private volatile boolean stop = false;
    private Thread self;
    static Lock lock = new ReentrantLock();

    public void cancel() {
        this.stop = true;
        this.self.interrupt();
    }

    @Override
    public void run() {
        this.self = Thread.currentThread();
        System.out.printf("%s: startup\n", this.self.getName());
        while (!this.stop) {
            var blocked = true;
            try {
                lock.lock();
                blocked = false;
                try {
                    System.out.printf("%s: working\n", this.self.getName());
                    Thread.sleep(8000);
                } finally {
                    lock.unlock();
                }
            } catch (InterruptedException e) {
                if (blocked) {
                    System.err.printf("%s: blocked state interrupted\n", this.self.getName());
                } else {
                    System.err.printf("%s: working interrupted\n", this.self.getName());
                }
            }
        }
        System.out.printf("%s: shutdown\n", this.self.getName());
    }
}
