# Locks #

## Unterbrechbarkeit von Threads, die blockiert sind ##

## Lösungsskizze ##
* Untersuchen Sie das Verhalten in Bezug auf die Unterbrechbarkeit von ``Worker``

* Bauen Sie Worker zur Verwendung von ``ReentrantLock`` um.  

=> ``io.dama.ffi.reentrant.regular.Worker``

=> Der Lock muss von allen Instanzen der ``Worker``-Klasse sichtbar sein. Deshalb wird hier ein Klassenattribut in Form einer ``static``-Variable verwendet.

=> Um unterscheiden zu können, ob (bzw. wann) ein blockierter Thread ``interrupted()`` werden kann, wird die lokale ``boolean``-Variable ``blocked`` eingeführt. Sie ist initial auf ``true``, was an der Stelle missverständlich ist, da der ``Worker`` anfangs ja nicht geblockt ist. Sobald der Lock "überwunden" ist (Zeile 24), wird die Variable auf ``false`` gesetzt, weil nun klar ist, dass der Thread nicht blockiert ist, sondern arbeitet. Wird nun ein Interrupt ausgelöst, wird direkt zum entsprechenden ``catch``-Block gesprungen. Hier wird der Wert der Variablen ``blocked`` geprüft. 

Sollte der Wert ``true`` sein, heißt dies, dass der Thread noch keine Gelegenheit hatte, den Lock zu überwinden. Höchstwahrscheinlich ist der Thread also durch ``Worker.lock.lock()`` blockiert. Es könnte allerdings auch sein, dass ``Worker.lock.lock()`` noch nicht ausgeführt wurde. Da der Interrupt in diesem Programm aber erst mindestens 1000 ms nach Start des Threads ausgeführt wird, ist die Wahrscheinlichkeit dafür sehr gering.

Ist der Wert von ``blocked`` hingegen ``false``, ist klar, dass der Thread den Lock acquirieren konnte. Er ist also nicht blockiert, wenn der Interrupt im ``catch``-Block behandelt wird. 

* Untersuchen Sie das Verhalten in Bezug auf die Unterbrechbarkeit erneut. Prüfen Sie den Effekt von ``lockInterruptibly()`` im Vergleich zu ``lock()``.

=> ``io.dama.ffi.reentrant.interruptibly.Worker``: statt ``Worker.lock.lock()`` in Zeile 23 ``Worker.lock.lockInterruptibly()``

=> Der wegen ``lockInterruptibly()`` blockierte zweite Thread kann durch den Interrupt unterbrochen werden. Die Ausgabe auf ``System.err`` aus dem Catch-Block (rot in Eclipse-Console) erfolgt direkt.   

=> Im Gegensatz dazu werden die Interrupts im ``Worker`` in ``io.dama.ffi.reentrant.regular`` nie im blockierten Zustand behandelt. 