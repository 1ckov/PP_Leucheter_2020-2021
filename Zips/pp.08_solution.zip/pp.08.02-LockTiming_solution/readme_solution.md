# Locks #

## Vergleich von ``ReentrantLock``, ``ReentrantReadWriteLock``, ``StampedLock`` und ``synchronized`` ##


## Lösungsskizze ##
* Bilden Sie von der abstrakten Klasse ``Experiment`` Unterklassen namens ``ExpSynchronized``, ``ExpReentrantLock``, ``ExpReadWriteLock`` und ``ExpStampedLock``. Überschreiben Sie die abstrakten Methoden 

	public abstract void incCounter();
	public abstract int getCounter();

jeweils mit threadsicheren Implementierungen, die entweder ``synchronized``, ``ReentrantLock``, ``ReentrantReadWriteLock`` oder ``StampedLock`` zur Koordination des nebenläufigen Zugriffs auf die Instanzvariable ``counter`` verwenden. 

=> ``ExpSynchronized``: Verwendung des Schlüsselworts ``synchronized`` bei beiden Methoden

=> ``ExpReentrantLock``: Es wird eine neue Instanzvariable vom Typ ``ReentrantLock`` namens `` lock`` eingeführt, die im Konstruktor initialisiert wird. Der Bool'sche Parameter beim Konstruktor von ``ReentrantLock`` bestimmt die Fairness beim Wechsel zum jeweils nächsten von mehreren an diesem Lock blockierten Threads. 

``unlock()`` sollte immer in einem ``finally``-Block ausgeführt werden, um auch mit *unchecked Exceptions*, also solchen, die von ``RuntimeException`` erben, umgehen zu können. 

=> ``ExpReadWriteLock``: Es wird eine neue Instanzvariable vom Typ ``ReadWriteLock`` namens `` lock`` eingeführt, die im Konstruktor initialisiert wird. Der Bool'sche Parameter beim Konstruktor von ``ReadWriteLock`` bestimmt wieder die Fairness beim Wechsel zum jeweils nächsten von mehreren an diesem Lock blockierten Threads.

Zusätzlich gibt es zwei Instanzvariablen vom Typ ``Lock``, die im Konstruktor vom ``ReadWriteLock`` geholt werden: Eine mit ``readLock()``, die andere mit ``writeLock()``. Beim Modifizieren der zu schützenden Variable ``counter`` in der Methode ``incCounter`` wird der *Write-Lock* beim Lesen in ``getCounter`` der *Read-Lock* benutzt. 

``unlock()`` (sowohl auf den *Write-Lock*, als auch auf den *Read-Lock*) sollte immer in einem ``finally``-Block ausgeführt werden, um auch mit *unchecked Exceptions*, also solchen, die von ``RuntimeException`` erben, umgehen zu können. 

=> ``ExpStampedLock``: ``java.util.concurrent.locks.StampedLock`` gibt es erst ab Java 8. Es wird eine neue Instanzvariable vom Typ ``StampedLock`` namens `` lock`` eingeführt, die im Konstruktor initialisiert wird. 

Da die vor konkurrierenden Zugriffen zu schützende Variable ``counter`` in ``incCounter()`` verändert wird, muss hier der ``writeLock(...)`` zum Zugriffssschutz verwendet werden. In ``getCounter()`` hingegen kann *optimistisches Lesen* benutzt werden. 

``unlock()`` (sowohl auf den *Write-Lock*, als auch auf den *Read-Lock*) sollte immer in einem ``finally``-Block ausgeführt werden, um auch mit *unchecked Exceptions*, also solchen, die von ``RuntimeException`` erben, umgehen zu können. 

* Verwenden Sie die ``main``-Methode wie in ``ExpUnsynchronized``, also

	public static void main(final String... args) throws InterruptedException {
	    (new ExpUnsynchronized()).experimentPar();
	}

oder eine vergleichbare Funktionalität, um die Laufzeit mit zwei Threads und einem steuerbaren Verhältnis von lesenden und ändernden Zugriffen zu analysieren.

* Führen Sie Messungen der Laufzeit durch.

=> s. Folien

* Vergleichen Sie auch das Zeitverhalten für ``ReentrantLock(false)`` und ``ReentrantLock(true)`` sowie analog bei ``ReentrantReadWriteLock(false)`` und ``ReentrantReadWriteLock(true)``.

=> s. Folien