package io.dama.ffi.locks;

import java.util.concurrent.locks.StampedLock;;

public class ExpStampedLock extends Experiment {
    private final StampedLock lock;

    public ExpStampedLock() {
        this.lock = new StampedLock();
    }

    @Override
    public void incCounter() {
        var stamp = this.lock.writeLock();
        try {
            this.counter++;
        } finally {
            this.lock.unlockWrite(stamp);
        }
    }

    @Override
    public int getCounter() {
        var result = this.counter;
        var stamp = this.lock.tryOptimisticRead();
        if (!this.lock.validate(stamp)) {
            // nicht erfolgreich
            stamp = this.lock.readLock();
            try {
                result = this.counter;
            } finally {
                this.lock.unlockRead(stamp);
            }
        }
        return result;
    }

    public static void main(final String... args) throws InterruptedException {
        (new ExpStampedLock()).experimentPar();
    }

}
