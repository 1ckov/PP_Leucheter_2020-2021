package io.dama.ffi.locks;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;;

public class ExpReadWriteLock extends Experiment {
    private final ReadWriteLock lock;
    private final Lock rLock;
    private final Lock wLock;

    public ExpReadWriteLock() {
        this.lock = new ReentrantReadWriteLock(false); // fair==true => (noch) langsamer
        this.rLock = this.lock.readLock();
        this.wLock = this.lock.writeLock();
    }

    @Override
    public void incCounter() {
        this.wLock.lock();
        try {
            this.counter++;
        } finally {
            this.wLock.unlock();
        }
    }

    @Override
    public int getCounter() {
        this.rLock.lock();
        try {
            return this.counter;
        } finally {
            this.rLock.unlock();
        }
    }

    public static void main(final String... args) throws InterruptedException {
        (new ExpReadWriteLock()).experimentPar();
    }

}
