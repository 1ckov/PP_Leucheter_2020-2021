package io.dama.ffi.locks;

import java.util.concurrent.locks.ReentrantLock;

public class ExpReentrantLock extends Experiment {
    private final ReentrantLock lock;

    public ExpReentrantLock() {
        this.lock = new ReentrantLock(false); // fair==true => (noch) langsamer
    }

    @Override
    public void incCounter() {
        this.lock.lock();
        try {
            this.counter++;
        } finally {
            this.lock.unlock();
        }
    }

    @Override
    public int getCounter() {
        this.lock.lock();
        try {
            return this.counter;
        } finally {
            this.lock.unlock();
        }
    }

    public static void main(final String... args) throws InterruptedException {
        (new ExpReentrantLock()).experimentPar();
    }

}
