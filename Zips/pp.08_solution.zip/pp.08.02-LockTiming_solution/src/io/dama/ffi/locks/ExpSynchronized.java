package io.dama.ffi.locks;

public class ExpSynchronized extends Experiment {

    @Override
    public synchronized void incCounter() {
        this.counter++;
    }

    @Override
    public synchronized int getCounter() {
        return this.counter;
    }

    public static void main(final String... args) throws InterruptedException {
        (new ExpSynchronized()).experimentPar();
    }
}
