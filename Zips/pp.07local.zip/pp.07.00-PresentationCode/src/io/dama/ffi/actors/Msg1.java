package io.dama.ffi.actors;

public class Msg1 {

}
