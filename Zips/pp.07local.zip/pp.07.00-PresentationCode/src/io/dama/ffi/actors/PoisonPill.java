package io.dama.ffi.actors;

public class PoisonPill {

}
