package io.dama.ffi.messages;

public class PleaseCleanupAndStop {

}
