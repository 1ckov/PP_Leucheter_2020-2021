package io.dama.ffi.actors.find.messages;

public class PleaseCleanupAndStop {

}
