package io.dama.ffi.actors.find;

public class ListenerActor {
}
