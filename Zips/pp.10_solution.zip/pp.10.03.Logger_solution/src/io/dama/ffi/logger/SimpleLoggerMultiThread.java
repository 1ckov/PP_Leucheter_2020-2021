package io.dama.ffi.logger;

import java.io.PrintStream;

public class SimpleLoggerMultiThread implements Logging, AutoCloseable {
    private static final int    CAPACITY = 1024;
    private final StringBuilder log      = new StringBuilder(SimpleLoggerMultiThread.CAPACITY);
    private Severity            level;
    private PrintStream         out;

    public SimpleLoggerMultiThread() {
        setSeverityLevel(Logging.Severity.Warning);
        setPrintStream(System.err);
    }

    public SimpleLoggerMultiThread(final Severity level) {
        this();
        setSeverityLevel(level);
    }

    public SimpleLoggerMultiThread(final Severity level, final PrintStream out) {
        this(level);
        setPrintStream(out);
    }

    @Override
    public synchronized void log(final Severity level, final String msg) {
        if (this.level.ordinal() <= level.ordinal()) {
            this.log.append(Thread.currentThread().getName()).append(" : ").append(msg).append(System.lineSeparator());
            if (this.log.length() > SimpleLoggerMultiThread.CAPACITY) {
                flush();
            }
        }
    }

    @Override
    public synchronized void flush() {
        if (this.log.length() > 0) {
            this.out.print(this.log);
            this.out.flush();
            this.log.setLength(0);
        }
    }

    @Override
    public synchronized void setSeverityLevel(final Severity level) {
        this.level = level;
    }

    @Override
    public synchronized void setPrintStream(final PrintStream out) {
        this.out = out;
    }

    @Override
    public void close() throws Exception {
        flush();
    }
}
