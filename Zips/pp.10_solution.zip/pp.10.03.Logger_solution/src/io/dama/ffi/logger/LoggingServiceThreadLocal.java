package io.dama.ffi.logger;

import java.io.FileNotFoundException;
import java.io.PrintStream;

public class LoggingServiceThreadLocal implements Logging {
    @SuppressWarnings("resource")
    private static ThreadLocal<Logging> logger = ThreadLocal.withInitial(() -> {
        PrintStream out = null;
        try {
            out = new PrintStream(Thread.currentThread().getName() + ".log");
        } catch (FileNotFoundException e) {
            out = System.err;
        }
        return new SimpleLoggerSingleThread(Logging.Severity.Warning, out);
    });

    private static Logging get() {
        return LoggingServiceThreadLocal.logger.get();
    }

    @Override
    public void log(final Severity level, final String msg) {
        // braucht nicht synchronized sein
        LoggingServiceThreadLocal.get().log(level, msg);
    }

    @Override
    public void flush() {
        LoggingServiceThreadLocal.get().flush();
    }

    @Override
    public void setSeverityLevel(final Severity level) {
        LoggingServiceThreadLocal.get().setSeverityLevel(level);
    }

    @Override
    public void setPrintStream(final PrintStream out) {
        LoggingServiceThreadLocal.get().setPrintStream(out);
    }
}
