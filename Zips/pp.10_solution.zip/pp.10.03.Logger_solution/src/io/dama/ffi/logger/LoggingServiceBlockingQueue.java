package io.dama.ffi.logger;

import java.io.PrintStream;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

final class LoggingServiceBlockingQueue extends Thread implements Logging {
    private static LoggingServiceBlockingQueue instance = new LoggingServiceBlockingQueue();
    private static final Logging logger = new SimpleLoggerSingleThread();
    private final BlockingQueue<String> queueDebug = new LinkedBlockingQueue<>();
    private final BlockingQueue<String> queueInformational = new LinkedBlockingQueue<>();
    private final BlockingQueue<String> queueNotice = new LinkedBlockingQueue<>();
    private final BlockingQueue<String> queueWarning = new LinkedBlockingQueue<>();
    private final BlockingQueue<String> queueError = new LinkedBlockingQueue<>();
    private final BlockingQueue<String> queueCritical = new LinkedBlockingQueue<>();
    private final BlockingQueue<String> queueAlert = new LinkedBlockingQueue<>();
    private final BlockingQueue<String> queueEmergency = new LinkedBlockingQueue<>();

    private LoggingServiceBlockingQueue() {
        setDaemon(true);
        setPriority(Thread.MIN_PRIORITY);
        start(); // hier kein Problem, da Klasse final (s. pp.01.01-Inheritance)
    }

    public static Logging get() {
        return LoggingServiceBlockingQueue.instance;
    }

    @Override
    public void run() {
        while (true) {
            try {
                var msg = "";
                if ((msg = this.queueEmergency.poll()) != null) {
                    LoggingServiceBlockingQueue.logger.log(Severity.Emergency, msg);
                } else if ((msg = this.queueAlert.poll()) != null) {
                    LoggingServiceBlockingQueue.logger.log(Severity.Alert, msg);
                } else if ((msg = this.queueCritical.poll()) != null) {
                    LoggingServiceBlockingQueue.logger.log(Severity.Critical, msg);
                } else if ((msg = this.queueError.poll()) != null) {
                    LoggingServiceBlockingQueue.logger.log(Severity.Error, msg);
                } else if ((msg = this.queueWarning.poll()) != null) {
                    LoggingServiceBlockingQueue.logger.log(Severity.Warning, msg);
                } else if ((msg = this.queueNotice.poll()) != null) {
                    LoggingServiceBlockingQueue.logger.log(Severity.Notice, msg);
                } else if ((msg = this.queueInformational.poll()) != null) {
                    LoggingServiceBlockingQueue.logger.log(Severity.Informational, msg);
                } else if ((msg = this.queueDebug.poll()) != null) {
                    LoggingServiceBlockingQueue.logger.log(Severity.Debug, msg);
                }
            } catch (Exception ex) {
            }
        }
    }

    @Override
    public void log(final Severity level, final String msg) {
        // braucht nicht synchronized sein!
        var success = false;
        while (!success) { // falls die jeweilige Queue schon voll ist (success == false) nochmal probieren
            switch (level) {
            case Debug:
                success = this.queueDebug.offer(msg);
            case Informational:
                success = this.queueInformational.offer(msg);
            case Notice:
                success = this.queueNotice.offer(msg);
            case Warning:
                success = this.queueWarning.offer(msg);
            case Error:
                success = this.queueError.offer(msg);
            case Critical:
                success = this.queueCritical.offer(msg);
            case Alert:
                success = this.queueAlert.offer(msg);
            case Emergency:
                success = this.queueEmergency.offer(msg);
            }
        }
    }

    @Override
    public void flush() {
        LoggingServiceBlockingQueue.logger.flush();
    }

    @Override
    public void setSeverityLevel(final Severity level) {
        LoggingServiceBlockingQueue.logger.setSeverityLevel(level);
    }

    @Override
    public void setPrintStream(final PrintStream out) {
        LoggingServiceBlockingQueue.logger.setPrintStream(out);
    }
}
