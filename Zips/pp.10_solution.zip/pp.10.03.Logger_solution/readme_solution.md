# Anwendungsbeispiel Logging #

##  Exchanger und Blocking Queues  ##

*Logger* nehmen Nachrichten an, die während des (operativen) Betriebs von Systemen ausgegeben oder gespeichert werden sollen. Dies kann für die Fehlersuche hilfreich oder aber auch zur Erfüllung von Audit-Anforderungen erforderlich sein. Das Logging ist eine Nebenaufgabe und sollte das System möglichst wenig belasten. 

Generell unterscheidet man bei Loggern mehrere Schwerestufen: Eine Nachricht ist dabei immer einer Schwerestufe zugeordnet. Die Konfiguration des Loggers besteimmt, ab welcher Schwerestufe Nachrichten relevant sind und ausgegeben oder gespeichert werden sollen. Für den operativen Betrieb von Systemen können Nachrichten eines besonders hohen Schweregrads auch über Kommunikationssysteme an Verantwortliche geschickt werden, statt sie beispielsweise nur auf der Konsole auszugeben.

[RFC 5424](https://tools.ietf.org/html/rfc5424) *(Syslog Protocol)* ist ein Standard, der die Schnittstelle für einen zentralen Logging-Dienst in einem verteilten System beschreibt. Im [RFC 5424](https://tools.ietf.org/html/rfc5424)-Standard sind die folgenden Schweregradstufen *("Severity-Levels")* definiert:

* Emergency
* Alert
* Critical
* Error
* Warning
* Notice* 
* Informational
* Debug

Das Logging in verteilten Systemen ist es eine komplexe Aufgabe: Zu den Herausforderungen zählen der Umgang mit dem Timing (Uhren auf Knoten können unterschiedlich gehen) und das Herstellen von Bezügen zwischen Meldungen unterschiedlicher Knoten.

Ein zentraler Bestandteil von Loggern in verteilten Systemen sind mehrere Puffer, damit loggende Threads sich nicht wegen der nebenläufigen Nutzung des Pufferspeichers gegenseitig blockieren.

## Lösungsskizze ##

Im vorliegenden Anwendungsbeispiel soll einfacher Logger entwickelt werden, der Ausgaben auf der Konsole macht. Der Logger soll die nebenläufige Nutzung aus mehreren Threads heraus unterstützen. 

### Interface ``io.dama.ffi.logger.Logging`` ###

Im Folgenden wird es vier alternative Varianten des Loggers geben, die unterschiedliche Strategien aus PP nutzen. In ``io.dama.ffi.logger.Logging`` ist ein gemeinsames Interface spezifiziert, das von allen Varianten genutzt werden soll.

### ``SimpleLoggerSingleThread`` ###

Dies ist die nicht Thread-sichere Basisimplementierung des Logging-Interfaces.

### ``SimpleLoggerMultiThread`` ###

* Verwenden Sie die nicht Thread-sichere Basisimplementierung ``SimpleLoggerSingleThread`` und machen Sie sie Thread-sicher, indem Sie gegenseitigen Aussschluss benutzen.

- Die Klasse ``StringBuilder`` ist im Gegensatz zu ``StringBuffer`` nicht Thread-sicher. Außerdem wäre es wünschenswert, dass die Properties ``SeverityLevel`` und ``PrintStream`` nicht geändert werden, währen``log`` oder ``flush`` gerade arbeiten. Damit diese vier Methoden im gegenseitigen Ausschluss arbeiten, kann ``synchronized`` oder ein anderer Lock-Mechanismus verwendet werden.

### ``LoggingServiceThreadLocal`` ###

* Entwickeln Sie eine alternative Implementierung des Interfaces ``io.dama.ffi.logger.Logging``, bei der jeder Thread seine eigene Instanz des nicht Thread-sicheren  ``SimpleLoggerSingleThread`` verwendet. In der Klasse sind die Implementierungen der Methoden des Interface bereits enthalten. Ihre Aufgabe ist es die Initialisierung von ``logger`` zu programmieren. 

- Die Variable ``logger`` soll den Zugriff auf eine Thread-lokale Instanz von ``SimpleLoggerSingleThread`` ermöglichen. Dazu muss ein ``ThreadLocal``-Objekt als Wrapper erzeugt werden. Die Factory-Methode ``withInitial`` erzeugt den Wrapper und führt die übergebene Methode (*single abstract method* eines Objekts, dessen Klasse das Interface ``Supplier`` implementiert) zur Initialisierung aus.

	ThreadLocal.withInitial(() -> { /* ... * / }

Das Ergebnis der Methode muss ein neues Objekt vom Typ ``SimpleLoggerSingleThread`` sein.

	return new SimpleLoggerSingleThread(Logging.Severity.Warning, out);
	
Dafür muss vorher noch der ``PrintStream`` ``out`` vorbereitet werden:

	PrintStream out = null;
	try {
		out = new PrintStream(Thread.currentThread().getName() + ".log");
	} catch (FileNotFoundException e) {
		out = System.err;
	}
	
### ``LoggingServiceBlockingQueue``###

* Bei dieser Implementierung des Interfaces ``Logging`` soll der Logger als eigenständiger Thread laufen. Dieser Thread liest zu loggende Nachrichten aus unterschiedlichen ``BlockingQueue`` für die zu unterstützenden Prioritäten lesen. Die Synchronisierung des Logging wird also im Go-Stil durch die Nutzung von Kanälen realisiert.

- Das eigentliche Logging soll von einer nicht Thread-sicheren Instanz von ``SimpleLoggerSingleThread`` übernommen werden. Dazu wird eine Klassenvariable erzeugt und initialisiert:

	private static final Logging logger = new SimpleLoggerSingleThread();

- Die Queues müssen als Instanzvariablen erzeugt und mit leeren ``LinkedBlockingQueues`` initialisiert werden: 

    private final BlockingQueue<String> queueDebug = new LinkedBlockingQueue<>();
    private final BlockingQueue<String> queueInformational = new LinkedBlockingQueue<>();
    private final BlockingQueue<String> queueNotice = new LinkedBlockingQueue<>();
    private final BlockingQueue<String> queueWarning = new LinkedBlockingQueue<>();
    private final BlockingQueue<String> queueError = new LinkedBlockingQueue<>();
    private final BlockingQueue<String> queueCritical = new LinkedBlockingQueue<>();
    private final BlockingQueue<String> queueAlert = new LinkedBlockingQueue<>();
    private final BlockingQueue<String> queueEmergency = new LinkedBlockingQueue<>();

- In der ``run``-Methode dann muss laufend geprüft werden, ob Nachrichten in den Queues vorliegen. In Go gibt es dafür die ``select``-Schleife. In Java muss das nachgebildet werden. Mit ``poll`` kann nicht-blockierend geprüft werden, ob Nachrichten in den Queues vorliegen. Etwaige Nachrichten werden über die nicht Thread-sichere private Instanz von ``SimpleLoggerSingleThread`` geloggt. 

	while (true) {
	    try {
	        var msg = "";
	        if ((msg = this.queueEmergency.poll()) != null) {
	            LoggingServiceBlockingQueue.logger.log(Severity.Emergency, msg);
	        } else if ((msg = this.queueAlert.poll()) != null) {
	            LoggingServiceBlockingQueue.logger.log(Severity.Alert, msg);
	        } else if ((msg = this.queueCritical.poll()) != null) {
	            LoggingServiceBlockingQueue.logger.log(Severity.Critical, msg);
	        } else if ((msg = this.queueError.poll()) != null) {
	            LoggingServiceBlockingQueue.logger.log(Severity.Error, msg);
	        } else if ((msg = this.queueWarning.poll()) != null) {
	            LoggingServiceBlockingQueue.logger.log(Severity.Warning, msg);
	        } else if ((msg = this.queueNotice.poll()) != null) {
	            LoggingServiceBlockingQueue.logger.log(Severity.Notice, msg);
	        } else if ((msg = this.queueInformational.poll()) != null) {
	            LoggingServiceBlockingQueue.logger.log(Severity.Informational, msg);
	        } else if ((msg = this.queueDebug.poll()) != null) {
	            LoggingServiceBlockingQueue.logger.log(Severity.Debug, msg);
	        }
	    } catch (Exception ex) {
	    }
	}
	
