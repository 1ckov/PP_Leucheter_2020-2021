package io.dama.ffi.rendezvous;

/*-

package main
import "fmt"
func tasker (c, r chan int, d chan bool) {
    c <- 1; c <- 2
    fmt.Println (<-r); d <- true
}
func add (c, r chan int) {
    r <- <-c + <-c
}
func main () {
    c, r:= make(chan int), make(chan int)
    done:= make(chan bool)
    go tasker (c, r, done)
    go add (c, r)
    <-done
}

 */

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

class Addierer {
    private static void tasker(final int x, final int y, //
            final BlockingQueue<Integer> c, //
            final BlockingQueue<Integer> r, //
            final BlockingQueue<Boolean> d) {
        try {
            c.offer(x);
            c.offer(y);
            System.out.printf("%d+%d=%d\n", x, y, r.take());
            d.put(true);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static void add(final BlockingQueue<Integer> c, final BlockingQueue<Integer> r) {
        try {
            r.put(c.take() + c.take());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(final String... args) throws InterruptedException {
        var c = new LinkedBlockingQueue<Integer>();
        var r = new LinkedBlockingQueue<Integer>();
        var done = new LinkedBlockingQueue<Boolean>();
        (new Thread(() -> Addierer.tasker(1, 2, c, r, done))).start();
        (new Thread(() -> Addierer.add(c, r))).start();
        done.take();
    }
}
