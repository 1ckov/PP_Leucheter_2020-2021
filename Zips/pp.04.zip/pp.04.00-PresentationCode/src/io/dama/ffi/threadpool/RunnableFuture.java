package io.dama.ffi.threadpool;

public interface RunnableFuture<V> extends Runnable, Future<V> {

}
