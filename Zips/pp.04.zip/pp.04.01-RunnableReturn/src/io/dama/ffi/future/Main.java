package io.dama.ffi.future;

public class Main {

    public static void main(final String[] args) throws InterruptedException {
        // hier programmieren
    }

}
