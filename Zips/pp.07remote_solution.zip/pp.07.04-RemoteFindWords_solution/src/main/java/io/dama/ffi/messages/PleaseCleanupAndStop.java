package io.dama.ffi.messages;

import java.io.Serializable;

public class PleaseCleanupAndStop implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 7273183276322548603L;
}
