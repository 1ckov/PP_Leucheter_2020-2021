package io.dama.ffi.messages;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;

public class ResultMsg implements Serializable {
    /**
    *
    */
    private static final long serialVersionUID = 721745317803636199L;
    private final List<String> result;

    public ResultMsg(final List<String> result) {
        this.result = Collections.unmodifiableList(result);
    }

    public List<String> getResult() {
        return this.result;
    }
}
