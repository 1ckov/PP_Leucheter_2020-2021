package io.dama.ffi.router;

import com.typesafe.config.ConfigFactory;

import akka.actor.ActorSystem;

public class RemoteMain {

    public static void main(final String... args) {
        ActorSystem.create("remote", ConfigFactory.load("remoteChildren"));
    }
}
