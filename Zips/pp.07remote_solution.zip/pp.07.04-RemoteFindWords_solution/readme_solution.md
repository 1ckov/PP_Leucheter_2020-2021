# Actors #

## Akka-Actors mit Java: verteilte Actors und Router/Routees ##


### Lösungsskizze ###

* Damit kein großer Aufwand bei der Verteilung der Akka-Systeme in einem Netzwerk erforderlich ist, werden hier zwei getrennte Akka-Prozesse auf demselben Rechner gestartet. Sie kommen aber aus demselben Eclipse-Projekt, in dem zwei unterschiedliche Main-Klassen (Klassen mit der Methode ``public static void main(final String... args)``) enthalten sind, die nacheinander gestartet werden müssen.

- ``io.dama.ffi.router.RemoteMain``
- ``io.dama.ffi.router.MainApp1``/``io.dama.par.router.MainApp2``

* Die Main-Klassen haben jeweils unterschiedliche ``.conf``-Dateien. 

- ``io.dama.ffi.router.RemoteMain``: ``src/main/resources/remoteChildren.conf``
- ``io.dama.ffi.router.MainApp1``: ``src/main/resources/mainApp1.conf``
- ``io.dama.ffi.router.MainApp2``: ``src/main/resources/mainApp2.conf``

In den ``.conf``-Dateien ist jeweils *localhost* (``127.0.0.1``) bei unterschiedlichen Portnummern angegeben, so dass getrennte Akka-Systeme auf demselben Rechner gestartet werden können. Wenn sie miteinander kommunizieren werden TCP-Sockets benutzt. Der Java-Code unterscheidet sich dabei nicht von dem Fall, dass die Akka-Systeme tatsächlich auf unterschiedlichen Rechnern im Netzwerk verteilt wären. Lediglich die *Deploy*-Konfiguration müsste angepasst werden.
 

* Da die ``.conf``-Dateien eingelesen werden müssen, muss das Arbeitsverzeichnis (*working directory*) auf ``target/classes`` gesetzt werden. Am besten mit einer Run-Configuration innerhalb von Eclipse (funktioniert leider nicht problemlos mit maven).

* das pom.xml braucht statt der bisherigen *Dependency* ``akka-actor_2.12`` das folgende Artefakt:

	<dependency>
  		<groupId>com.typesafe.akka</groupId>
  		<artifactId>akka-remote_2.12</artifactId>
  		<version>2.5.12</version>
  	</dependency> 

* Bei verteilte Akka-Systemen müssen die Nachrichten serialisierbar sein, damit sie über das Netzwerk verschickt werden können. Deshalb müssen alle Nachrichtenklassen (``io.dama.ffi.messages.*``) das Interface ``Serializable`` implementieren. Es wäre wünschenswert (aber nicht notwendig), dass alle Nachrichtenklassen die ``long``-Konstante ``serialVersionUID`` besitzen und auf einen einmaligen und damit eindeutigen Wert setzen.

	public class PleaseCleanupAndStop implements Serializable {

        /**
         *
         */
        private static final long serialVersionUID = 7273183276322548603L;
		}

	public class FindMsg implements Serializable {
        /**
         *
         */
        private static final long  serialVersionUID = -7973852968183416435L;
        // ...
        

**Tipp:**

* ``ListenerActor``, ``WorkerActor`` und ``MasterActor`` (aus ``io.dama.ffi.router``) bleiben unverändert.
* ``io.dama.ffi.messages.*`` und die Hauptklasse (zum Starten) müssen an den verteilten Betrieb angepasst werden.
