package io.dama.ffi.hoh;

public class ThreadsafeSimplifiedList<T> extends ThreadsafeLinkedNewListReadWriteLock<T>{
	
}