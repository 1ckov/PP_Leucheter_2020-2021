package io.dama.ffi.hoh;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class ThreadsafeLinkedNewListReadWriteLock<T> implements SimplifiedList<T> {

	private Node<T> first;

	private class Node<U> {
		private U element;
		private final Node<U> prev;
		private Node<U> next;
		private final ReadWriteLock lock;
		private final Lock readLock;
		private final Lock writeLock;

		private Node(final U element, final Node<U> prev, final Node<U> next) {
			super();
			this.element = element;
			this.prev = prev;
			this.next = next;
			this.lock = new ReentrantReadWriteLock();
			this.readLock = this.lock.readLock();
			this.writeLock = this.lock.writeLock();
		}
	}

	public ThreadsafeLinkedNewListReadWriteLock() {
		super();
		this.first = null;
	}

	/**
	 * Returns the element at the specified position in this list.
	 *
	 * @param index index of the element to return
	 * @return the element at the specified position in this list
	 */
	@Override
	public T get(final int index) {
		Node<T> ptr = null;
		ptr = this.first;
		ptr.readLock.lock();
		try {
			for (var i = 0; i < index; i++) {
				if (ptr.next != null) {
					ptr.next.readLock.lock();
					ptr = ptr.next;
					ptr.prev.readLock.unlock();
				} else {
					throw new IndexOutOfBoundsException(i + 1);
				}
			}
			return delay(ptr.element);
		} finally {
			ptr.readLock.unlock();
		}
	}

	/**
	 * Appends the specified element to the end of this list. There are no
	 * limitations on what elements may be added to this list.
	 * 
	 * @param element element to be appended to this list
	 * @return true
	 * @see java.util.Collection#add(Object)
	 *
	 */
	@Override
	public boolean add(final T element) {
		if (this.first != null) {
			var ptr = this.first;
			ptr.readLock.lock();
			while (ptr.next != null) {
				ptr.next.readLock.lock();
				ptr = ptr.next;
				ptr.prev.readLock.unlock();
			}
			ptr.readLock.unlock();
			ptr.writeLock.lock();
			ptr.next = new Node<>(element, ptr, null);
			ptr.writeLock.unlock();
		} else {
			this.first = new Node<>(element, null, null);
		}
		return true;
	}

	/**
	 * Replaces the element at the specified position in this list with the
	 * specified element.
	 * 
	 * @param index   index of the element to replace
	 * @param element element to be stored at the specified position
	 * @return the element previously at the specified position
	 */
	@Override
	public T set(final int index, final T element) {
		Node<T> ptr = null;
		ptr = this.first;
		ptr.readLock.lock();
		for (var i = 0; i < index; i++) {
			if (ptr.next != null) {
				ptr.next.readLock.lock();
				ptr = ptr.next;
				ptr.prev.readLock.unlock();
			} else {
				throw new IndexOutOfBoundsException(i + 1);
			}
		}
		ptr.readLock.unlock();
		ptr.writeLock.lock();
		ptr.element = element;
		ptr.writeLock.unlock();
		return element;
	}

	/**
	 * Returns true if this list contains no elements.
	 * 
	 * @return true if this list contains no elements
	 */
	@Override
	public boolean isEmpty() {
		return this.first == null;
	}
}
