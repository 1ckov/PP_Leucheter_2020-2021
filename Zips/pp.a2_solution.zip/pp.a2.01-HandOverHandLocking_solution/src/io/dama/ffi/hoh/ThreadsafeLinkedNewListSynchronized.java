package io.dama.ffi.hoh;


public class ThreadsafeLinkedNewListSynchronized<T> implements SimplifiedList<T> {
	private Node<T> first;

	private class Node<U> {
		private U element;
		private final Node<U> prev;
		private Node<U> next;

		private Node(final U element, final Node<U> prev, final Node<U> next) {
			super();
			this.element = element;
			this.prev = prev;
			this.next = next;
		}
	}

	public ThreadsafeLinkedNewListSynchronized() {
		super();
		this.first = null;
	}

	/**
	 * Returns the element at the specified position in this list.
	 *
	 * @param index index of the element to return
	 * @return the element at the specified position in this list
	 */
	@Override
	public synchronized T get(final int index) {
		var ptr = this.first;
		for (var j = 0; j < index; j++) {
			ptr = ptr.next;
		}
		return delay(ptr.element);
	}

	/**
	 * Appends the specified element to the end of this list. There are no
	 * limitations on what elements may be added to this list.
	 * 
	 * @param element element to be appended to this list
	 * @return true
	 * @see java.util.Collection#add(Object)
	 *
	 */
	@Override
	public synchronized boolean add(final T element) {
		if (this.first != null) {
			var ptr = this.first;
			while (ptr.next != null) {
				ptr = ptr.next;
			}
			ptr.next = new Node<>(element, ptr, null);
		} else {
			this.first = new Node<>(element, null, null);
		}
		return true;
	}

	/**
	 * Replaces the element at the specified position in this list with the
	 * specified element.
	 * 
	 * @param index   index of the element to replace
	 * @param element element to be stored at the specified position
	 * @return the element previously at the specified position
	 */
	@Override
	public synchronized T set(final int index, final T element) {
		var ptr = this.first;
		for (var j = 0; j < index; j++) {
			ptr = ptr.next;
		}
		ptr.element = element;
		return element;
	}

	/**
	 * Returns true if this list contains no elements.
	 * 
	 * @return true if this list contains no elements
	 */
	@Override
	public synchronized boolean isEmpty() {
		return this.first == null;
	}
}
