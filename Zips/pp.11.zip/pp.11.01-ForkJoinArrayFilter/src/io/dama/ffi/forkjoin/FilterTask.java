package io.dama.ffi.forkjoin;

import java.util.ArrayList;
import java.util.concurrent.RecursiveAction;

@SuppressWarnings("serial")
public class FilterTask extends RecursiveAction {

    private static final int ARRAY_LEN = 16;
    private static final int SLICE_LEN = 4;
    private static final int MAX = 10;
    private static int instanceCounter = 0;

    private final ArrayList<Integer> array;
    private final int start;
    private final int end;

    FilterTask(final ArrayList<Integer> array, final int start, final int end) {
        this.array = array;
        this.start = start;
        this.end = end;
        instanceCounter++;
    }

    @Override
    protected void compute() {

        // Fallunterscheidung einführen, die prüft, ob weiter rekursiv halbiert werden
        // muss oder ob nun der Rekursionsanker erreicht ist

        // Rekursionsanker: über Array-Elemente mit einer for-Schleife iterieren und
        // Filter-Aktion anwenden
        // (muss noch implementiert werden)

        // Array in zwei Hälften aufteilen und beide Hälften rekursiv behandeln:
        var mid = this.start + ((this.end - this.start) / 2);
        var left = new FilterTask(this.array, this.start, mid);
        var right = new FilterTask(this.array, mid, this.end);
        left.fork();
        right.fork();
        left.join();
        right.join();
    }

    public static void main(final String... args) {
        // Array initialisieren

        // initialen FilterTask erzeugen und
        // FilterTask im *Common Thread Pool* starten:
        // ForkJoinPool.commonPool().invoke(...);

        // auf das Ende warten
        // gefiltertes Array ausgeben
    }

}
