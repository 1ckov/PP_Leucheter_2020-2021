# Locks #

## Unterbrechbarkeit von Threads, die blockiert sind ##

## Aufgaben ##
* Untersuchen Sie das Verhalten in Bezug auf die Unterbrechbarkeit von ``Worker``
* Bauen Sie Worker zur Verwendung von ``ReentrantLock`` um.  
* Untersuchen Sie das Verhalten in Bezug auf die Unterbrechbarkeit erneut. Prüfen Sie den Effekt von ``lockInterruptibly()`` im Vergleich zu ``lock()``.

