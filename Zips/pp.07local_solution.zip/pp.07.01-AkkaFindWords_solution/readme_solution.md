# Actors #

## Akka: Paralleles Suchen/Finden eines Suchstrings in Textdateien ##

## Lösungsskizze ##

### neue Klasse ``ListenerActor``

*Erstellen Sie die neue Klasse ``ListenerActor`` in Package ``io.dama.ffi.actors.find``. Sie soll von der Klasse ``akka.actor.AbstractActor`` erben und ``ResultMsg``-Objekte empfangen können. Beim Empfang solch einer Nachricht sollen alle Elemente des Properties ``Result`` ausgegeben werden. Danach soll das gesamte System mit ``getContext().getSystem().terminate();`` heruntergefahren werden.*

- Die Signatur der Methode ist in der Aufgabe spezifiziert:
  
	public class ListenerActor extends AbstractActor
  	
- Dies bedingt, dass die folgende Methode implementiert wird:
  
	@Override
	public Receive createReceive()
    
- In dieser Methode muss ein *"Match"* für Objekte des Typs ``ResultMsg`` vorgesehen werden:
  
	.match(ResultMsg.class, /* ... */
  	
- Falls solch ein Objekt empfangen wird, muss sein Inhalt ausgegeben werden und das Akka-System terminiert werden (als Lambda-Ausdruck formuliert):
  
	(msg) -> {
		msg.getResult().forEach(System.out::println);
		getContext().getSystem().terminate();
	}

### Konstruktor von ``MasterActor``

*Ein ``ListenerActor`` soll im Konstruktor von ``MasterActor`` erzeugt werden und in der Instanzvariablen ``listener`` gespeichert werden.*

- Ein neuer Actor wird mit der Methode ``actorOf`` erzeugt. Er wird in die Hierarchie der Aktoren dadurch einsortiert, dass diese Methode im übergeordneten Kontext erzeugt wird. Das ist hier der Kontext der ``MasterActor``-Instanz. Dieser Kontext wird durch ``getContext()`` von ``this`` (einem ``MasterActor``) geholt.

	this.listener = getContext().actorOf( /* ... */ );
	
- Die ``actorOf``-Methode bekomt hier zwei Parameter: Erstens eine Spezifikation des neuen Actors. Hier soll ein neuer ``ListenerActor`` erzeugt werden. Das komplexe ``Props``-Framework ist ebenso wie Akka eine Entwicklung der Firma *Lightbend*. Nehmen Sie es hier einfach als idomatischen Gebrauch hin. Eine genauere Erklärung würde hier zu weit gehen:

	Props.create(ListenerActor.class)
	
- Der zweite Parameter für die ``actorOf``-Methode ist ein symbolischer Name für den Actor, der ggf. auch zur Identifikation (anstatt des ``ActorRef``-Handles) herangezogen werden kann. Er wird als ``String``  übergeben:

	"listener"

### ``FindMsg`` mit ``MasterActor`` verarbeiten

*Der ``MasterActor`` soll beim Empfang einer ``FindMsg`` mit ``getFilenames()`` herausfinden, wieviele Dateien durchsucht werden sollen. Für jede Datei soll ein eigener ``WorkerActor`` erzeugt werden, dem sofort mit ``tell`` eine neue ``WorkMsg`` mit dem entsprechenden Auftrag geschickt wird.*

- Dazu muss die folgende Methode ausformuliert werden. Sie wird aufgrund des ``ReceiveBuilders`` aufgerufen, wenn eine ``FindMsg`` eintrifft:

	private void handleFindMsg(final FindMsg msg)
	
- Dazu wird der Inhalt der ``FindMsg`` analysiert: 

	var filenames = msg.getFilenames();
	var searchword = msg.getSearchword();
	
- Für jedes Element in ``filenames`` wird eine neue Nachricht erzeugt, die von Workern bearbeitet wird. Es ergibt sich für jede dieser Anfragen eine Antwort. Damit im laufenden Betrieb die Anzahl der jeweils noch zu erwartenden Antworten mitprotokolliert werden kann, wird die anfängliche Anzahl in der Instanzvariablen ``numOfChild`` gespeichert:

	this.numOfChild = msg.getFilenames().size();

- Dann wird für jedes Element in ``filenames`` eine neue Nachricht erzeugt, die das zu lösende Teilproblem enthält:

        for (var filename : filenames) {
            var job = new WorkMsg(filename, searchword);

- Jede dieser so erzeugten Nachrichten wird an einen jeweils neu und nur für diese Nachricht zuständigen ``WorkerActor`` gesendet (mit ``tell``), der erst direkt zuvor erzeugt wird:

            var findActor = getContext().actorOf(Props.create(WorkerActor.class));
            findActor.tell(job, getSelf());
        }


### ``WorkerActor``
*Der ``WorkerActor`` soll eine Nachricht vom Typ ``ResultMsg`` an den ``MasterActor`` zurücksenden, wenn er fertig ist. In der ``ResultMsg`` soll das Ergebnis (lokale Variable ``result``) enthalten sein.*

- Die Methode ``handleWorkMsg`` muss vervollständigt werden. Das Ergebnis liegt in der lokalen Variablen ``result``vor. Es muss in eine neue ``ResultMsg`` getan werden:

	new ResultMsg(result)
	
- Diese ``ResultMsg`` wird mit der Methode ``tell`` an den Absender der hier gerade verarbeiteten ``WorkMsg`` zurückgesendet. Dies ist der ``MasterActor``. Dessen ``ActorRef`` kann mit der Methode ``getSender`` ermittelt werden. Das Akka-Framework sorgt dafür, dass dabei der Absender der Nachricht, die gerade verarbeitet wird, ermittelt wird.

	getSender().tell( /* ... */ );
	 
- Als Absender dieser Nachricht wird der gerade arbeitende ``WorkerActor`` eingetragen (2. Parameter von ``tell``), der mit der folgenden Methode ermittelt wird: 

	getSelf()
 