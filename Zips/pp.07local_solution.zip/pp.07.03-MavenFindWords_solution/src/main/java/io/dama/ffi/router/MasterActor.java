package io.dama.ffi.router;

import java.util.ArrayList;
import java.util.List;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.Props;
import akka.routing.ActorRefRoutee;
import akka.routing.RoundRobinRoutingLogic;
import akka.routing.Routee;
import akka.routing.Router;
import io.dama.ffi.ListenerActor;
import io.dama.ffi.WorkerActor;
import io.dama.ffi.messages.FindMsg;
import io.dama.ffi.messages.PleaseCleanupAndStop;
import io.dama.ffi.messages.ResultMsg;
import io.dama.ffi.messages.WorkMsg;

public class MasterActor extends AbstractActor {
    private static final int WORKER_NUM = 5;
    private int numOfOpenSubTasks;
    private final List<String> result = new ArrayList<>();
    // final bei den entsprechenden Instanzvariablen setzen
    private final ActorRef listener;
    private final List<Routee> routees;
    private final Router router;

    public MasterActor() {
        // this.listener = ein neuer ListenerActor
        this.listener = getContext().actorOf(Props.create(ListenerActor.class), "listener");
        // optional: this.listener überwachen
        getContext().watch(this.listener);
        // this.routees mit leerer Liste initialisieren
        this.routees = new ArrayList<>();
        // Zählschleife von 0 bis MasterActor.WORKER_NUM-1
        for (var i = 0; i < MasterActor.WORKER_NUM; i++) {
            // - neuen WorkerActor erzeugen
            var r = getContext().actorOf(Props.create(WorkerActor.class), "worker-" + (i + 1));
            // - optional: WorkerActor überwachen
            getContext().watch(r);
            // - Routee für WorkerActor erzeugen (Konstruktor ActorRefRoutee)
            // - Routee der Liste this.routees hinzufügen
            this.routees.add(new ActorRefRoutee(r));
        }
        // this.router = neuer Router mit passender Logik und this.routees als Routees
        this.router = new Router(new RoundRobinRoutingLogic(), this.routees);
    }

    @Override
    public Receive createReceive() {
        return receiveBuilder() //
                .match(FindMsg.class, this::handleFindMsg) //
                .match(ResultMsg.class, this::handleResultMsg) //
                .build();
    }

    private void handleFindMsg(final FindMsg msg) {
        var filenames = msg.getFilenames();
        var searchword = msg.getSearchword();

        // über alle fileNames der FindMsg iterieren:
        for (var filename : filenames) {
            // - neue WorkMsg erzeugen
            var job = new WorkMsg(filename, searchword);
            // - WorkMsg mit route an Router schicken
            this.router.route(job, getSelf());
            // - numOfOpenSubTasks++
            this.numOfOpenSubTasks++;
        }
    }

    private void handleResultMsg(final ResultMsg msg) {
        this.numOfOpenSubTasks--;
        this.result.addAll(msg.getResult());
        if (this.numOfOpenSubTasks == 0) {
            for (var routee : this.routees) {
                routee.send(new PleaseCleanupAndStop(), getSelf());
            }
            this.listener.tell(new ResultMsg(this.result), getSelf());
            getContext().stop(getSelf());
        }
    }
}
