package io.dama.ffi.actor;

import java.util.ArrayList;
import java.util.List;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.Props;
import io.dama.ffi.ListenerActor;
import io.dama.ffi.WorkerActor;
import io.dama.ffi.messages.FindMsg;
import io.dama.ffi.messages.PleaseCleanupAndStop;
import io.dama.ffi.messages.ResultMsg;
import io.dama.ffi.messages.WorkMsg;

public class MasterActor extends AbstractActor {
    private int numOfOpenSubTasks;
    private final List<String> result = new ArrayList<>();
    // final bei den entsprechenden Instanzvariablen setzen
    private final ActorRef listener;

    public MasterActor() {
        // this.listener = ein neuer ListenerActor
        this.listener = getContext().actorOf(Props.create(ListenerActor.class), "listener");
        // optional: this.listener überwachen
        getContext().watch(this.listener);
    }

    @Override
    public Receive createReceive() {
        return receiveBuilder() //
                .match(FindMsg.class, this::handleFindMsg) //
                .match(ResultMsg.class, this::handleResultMsg) //
                .build();
    }

    private void handleFindMsg(final FindMsg msg) {
        var filenames = msg.getFilenames();
        var searchword = msg.getSearchword();

        // über alle fileNames der FindMsg iterieren:
        for (var filename : filenames) {
            // - neue WorkMsg erzeugen
            var job = new WorkMsg(filename, searchword);
            // - neuen WorkerActor erzeugen
            var workerActor = getContext().actorOf(Props.create(WorkerActor.class), "worker-" + this.numOfOpenSubTasks);
            // - optional: WorkerActor Überwachung starten
            getContext().watch(workerActor);
            // - WorkMsg mit tell an WorkerActor schicken
            workerActor.tell(job, getSelf());
            // - numOfOpenSubTasks++
            this.numOfOpenSubTasks++;
        }
    }

    private void handleResultMsg(final ResultMsg msg) {
        getSender().tell(new PleaseCleanupAndStop(), getSelf());
        this.numOfOpenSubTasks--;
        this.result.addAll(msg.getResult());
        if (this.numOfOpenSubTasks == 0) {
            this.listener.tell(new ResultMsg(this.result), getSelf());
            getContext().stop(getSelf());
        }
    }
}
