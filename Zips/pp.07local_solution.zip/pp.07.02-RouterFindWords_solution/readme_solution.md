# Actors #

## Akka: Paralleles Suchen/Finden eines Suchstrings in Textdateien ##

Aufbauend auf der Musterlösung von pp.07.01-AkkaFindWords soll ein Actor-System mit der Verwendung eines Routers entwickelt werden.

*Bauen Sie einen Router ein, der beliebig viele Aufträge auf *n* ``WorkerActor`` verteilt und dabei die *RoundRobinRoutingLogic* verwendet.*

## Lösungsskizze ##

### neue Instanzvariablen für ``MasterActor``
*Es empfiehlt sich die Routees, den Router und die Verbindung zwischen ihnen im Konstruktor von ``MasterActor`` zu erzeugen.*

- Die folgenden nicht veränderliches (``final``) privaten Instanzvariablen werden in ``MasterActor`` neu eingeführt:

    private final List<Routee> routees;
    private final Router router;

*Die Routees sind WorkerActor-Instanzen. Es ist sinnvoll, eine feste Anzahl von ihnen in einer Schleife zu erzeugen.*

- Die Anzahl der zu erzeugenden ``Routee``-Instanzen wird durch eine Konstante spezifiziert. Im Beispiel erhält Sie den Wert 5:

    private static final int WORKER_NUM = 5;

### Routees erzeugen

*Die Routees sind WorkerActor-Instanzen. Es ist sinnvoll, eine feste Anzahl von ihnen in einer Schleife zu erzeugen.*

- Die Anzahl von ``WORKER-NUM`` ``WorkerActor``-Instanzen wird im Konstruktor von ``MasterActor`` mit einer Schleife erzeugt. Sie sollen als ``ArrayList`` in der neuen Instanzvariablen ``routee`` gespeichert werden:

	this.routees = new ArrayList<>();
	for (var i = 0; i < MasterActor.WORKER_NUM; i++) {
		var r = getContext().actorOf(Props.create(WorkerActor.class));
		
- Da der ``MasterArctor`` diese Routees erzeugt, soll er sie auch (in seinem Kontext) im Sinne des Error Kernel Design Patterns überwachen:

		getContext().watch(r);

- Die ``WorkerActor``-Instanzen müssen über einen Wrapper vom Typ ``ActorRefRoutee`` zu Routees aufgewertet werden:

		this.routees.add(new ActorRefRoutee(r));
    }


### Router
*Als Router-Verhalten soll Round-Robin verwendet werden.*

- Zum Schluss wird im Konstruktor von ``MasterActor`` ein Router erzeugt und in der neuen Instanzvariable ``router`` gespeichert:

	this.router = new Router( /* ... */ );

- Die Parameter sind eine Spezifikation des Routing-Verhaltens (hier *Round-Robin*) und die Liste der vom Router zu bedienenden Routees:

	new RoundRobinRoutingLogic(), this.routees

### Einbinden des Routers

- Statt wie bisher beim Eintreffen von ``FindMsg`` alle Teilaufgaben (hier in der lokalen Laufvariablen ``job``) zu extrahieren, für jede einen neue Worker zu erzeugen und ihm den ``job`` mit ``tell`` zu schicken ...

	var findActor = getContext().actorOf(Props.create(WorkerActor.class));
	findActor.tell(job, getSelf());
	
- ... wird der ``job`` mit der Methode ``route`` an den Router übermittelt (dessen Routees ja schon im Konstruktor des ``MasterActor``  erzeugt und dem Router mitgeteilt wurden:

	this.router.route(job, getSelf());
	
- Da die Worker nun nicht mehr nach ihrer (Erst-) Benutzung gelöscht werden dürfen (sie bleiben ja als Routee im Verantwortungsbereich des Routers), muss ``handleResultMsg`` noch entsprechend angepasst werden. Bei jedem Eintreffen einer ``ResultMsg`` beim ``MasterActor`` muss die Anzahl der noch erwarteten Nachrichten um 1 heruntergezählt werden:

	this.numOfChild--;
	
- Das empfangene Teilergebnis muss nach wie vor in das Gesamtergebnis integriert werden:

	this.result.addAll(msg.getResult());
	
- Erst wenn keine Antworten mehr zu erwarten sind (``numOfChild`` bis 0 heruntergezählt), werden alle Worker durch jeweils eine neue ``PleaseCleanupAndStop``-Message heruntergefahren. Da die Worker als Routees in der Instanzvariablen  ``routees`` zu finden sind, kann darüber iteriert werden. Da es sich hier nicht um ``ActorRef``-Instanzen handelt (diese waren für die Speicherung in ``routees`` in ``ActorRefRoutee``-Instanzen gewrappt worden, wird zum Senden ``send`` und nicht ``tell`` benutzt:
	
	if (this.numOfChild == 0) {
		for (var routee : this.routees) {
			routee.send(new PleaseCleanupAndStop(), getSelf());
		}
		
- Am Ende wird noch der ``listener`` wie bisher auch heruntergefahren:

		this.listener.tell(new ResultMsg(this.result), getSelf());
		getContext().stop(getSelf());
	}

### Ändern der Aufgabe
*Verdoppeln Sie die Anzahl der Dateien, in denen gesucht werden soll, indem Sie Kopien der vier gegebenen Dateien erstellen. Dafür muss auch ``Main`` geändert werden.*

- Dazu kann in ``Main``das lokale String-Array geändert werden:

	String[] files = { "test1.txt", "test2.txt", "test3.txt", "test4.txt", "test5.txt", "test6.txt", "test7.txt",
                "test8.txt" };

- Die neuen Dateien müssen in das Wurzelverzeichnis des Projekts kopiert werden, denn das ist in diesem Projekt das Arbeitsverzeichnis.

*Sehen Sie weniger Routees als Dateien vor, damit gezeigt werden kann, dass Ihr Programm mit einer festen Anzahl von WorkerActor-Instanzen eine beliebige Anzahl von (Teil-) Aufgaben lösen kann.*

- Im Beispiel hier ist ``WORKER_NUM`` 5 und die Anzahl der zu durchsuchenden Dateien 8. Mindestens 3 ``WorkMsg``-Nachrichten müssen also von Routees verarbeitet werden, die mehr als eine Nachricht bekommen haben. 
