package io.dama.ffi.actors.find;

import java.util.ArrayList;
import java.util.List;

import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.Props;
import akka.routing.ActorRefRoutee;
import akka.routing.RoundRobinRoutingLogic;
import akka.routing.Routee;
import akka.routing.Router;
import io.dama.ffi.actors.find.messages.FindMsg;
import io.dama.ffi.actors.find.messages.PleaseCleanupAndStop;
import io.dama.ffi.actors.find.messages.ResultMsg;
import io.dama.ffi.actors.find.messages.WorkMsg;

public class MasterActor extends AbstractActor {
    private int numOfChild;
    private final List<String> result = new ArrayList<>();
    private final ActorRef listener;
    
    private final List<Routee> routees;
    private final Router router;

    private static final int WORKER_NUM = 5;

    public MasterActor() {
        this.listener = getContext().actorOf(Props.create(ListenerActor.class), "listener");
        this.routees = new ArrayList<>();
        for (var i = 0; i < MasterActor.WORKER_NUM; i++) {
            var r = getContext().actorOf(Props.create(WorkerActor.class));
            getContext().watch(r);
            this.routees.add(new ActorRefRoutee(r));
        }
        this.router = new Router(new RoundRobinRoutingLogic(), this.routees);
    }

    @Override
    public Receive createReceive() {
        return receiveBuilder() //
                .match(FindMsg.class, this::handleFindMsg) //
                .match(ResultMsg.class, this::handleResultMsg) //
                .build();
    }

    private void handleFindMsg(final FindMsg msg) {
        var filenames = msg.getFilenames();
        var searchword = msg.getSearchword();
        this.numOfChild = msg.getFilenames().size();
        for (var filename : filenames) {
            var job = new WorkMsg(filename, searchword);
            this.router.route(job, getSelf());
        }

    }

    private void handleResultMsg(final ResultMsg msg) {
        this.numOfChild--;
        this.result.addAll(msg.getResult());
        if (this.numOfChild == 0) {
            for (var routee : this.routees) {
                routee.send(new PleaseCleanupAndStop(), getSelf());
            }
            this.listener.tell(new ResultMsg(this.result), getSelf());
            getContext().stop(getSelf());
        }
    }

}
